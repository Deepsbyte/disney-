import styled from 'styled-components'

const Container = styled.div`
	min-height: 100vh;
	width: 100%;
	padding-top: 64px;
`

export default Container
