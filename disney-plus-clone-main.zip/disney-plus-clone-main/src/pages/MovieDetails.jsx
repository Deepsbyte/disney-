import Details from '@components/Details'

const MovieDetailsPage = () => {
	return <Details type='movie' />
}

export default MovieDetailsPage
