import Details from '@components/Details'

const SeriesDetailsPage = () => {
	return <Details type='tv' />
}

export default SeriesDetailsPage
