import DiscoverResource from '@components/DiscoverResource'

const DiscoverMoviesPage = () => {
	return <DiscoverResource type='movie' />
}

export default DiscoverMoviesPage
