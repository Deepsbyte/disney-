import DiscoverResource from '@components/DiscoverResource'

const DiscoverSeriesPage = () => {
	return <DiscoverResource type='series' />
}

export default DiscoverSeriesPage
